create trigger PAYMENT_TRIG
	before insert
	on PAYMENTS
	for each row
BEGIN
    SELECT pay_seq.NEXTVAL
    INTO   :new.PAYMENT_ID
    FROM   dual;
  END;