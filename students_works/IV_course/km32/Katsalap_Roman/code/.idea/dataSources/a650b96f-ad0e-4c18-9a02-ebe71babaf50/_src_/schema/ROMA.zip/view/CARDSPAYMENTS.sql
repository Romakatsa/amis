create view CARDSPAYMENTS as
SELECT P.payment_id payment_ID,
P.paydate PAYDATE,
P.amount AMOUNT,
P.phone_number PHONE_NUMBER,
P.card_no CARDNO,
C.token TOKEN,
C.card_name CARDNAME,
C.login LOGIN FROM ROMA.Payments P JOIN ROMA.Cards  C ON P.card_no = C.card_no
