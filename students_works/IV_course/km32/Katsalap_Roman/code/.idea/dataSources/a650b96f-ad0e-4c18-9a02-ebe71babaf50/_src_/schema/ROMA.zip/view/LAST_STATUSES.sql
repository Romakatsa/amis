create view LAST_STATUSES as
SELECT uas.login,groups.maxdate,uas.STATUS_NAME from users_account_statuses uas join (select us.login, max(us.DATE_OF_STATUS) maxdate from USERS_ACCOUNT_STATUSES us group by us.login) groups
      ON groups.maxdate = uas.DATE_OF_STATUS and groups.login = uas.LOGIN
